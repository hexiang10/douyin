imooc-red-book

linux安装软件已上传至实战群，请到群里下载噢~