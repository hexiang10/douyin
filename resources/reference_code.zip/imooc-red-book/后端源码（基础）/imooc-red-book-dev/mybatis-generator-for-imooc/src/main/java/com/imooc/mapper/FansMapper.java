package com.imooc.mapper;

import com.imooc.my.mapper.mapper.MyMapper;
import com.imooc.pojo.Fans;

public interface FansMapper extends MyMapper<Fans> {
}