package com.imooc.mapper;

import com.imooc.my.mapper.mapper.MyMapper;
import com.imooc.pojo.Comment;

public interface CommentMapper extends MyMapper<Comment> {
}