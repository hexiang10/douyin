package com.imooc.utils;

public class MyInfo {

    public static String getMobile() {
        return "";
    }

}
