package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.MyLikedVlog;

public interface MyLikedVlogMapper extends MyMapper<MyLikedVlog> {
}