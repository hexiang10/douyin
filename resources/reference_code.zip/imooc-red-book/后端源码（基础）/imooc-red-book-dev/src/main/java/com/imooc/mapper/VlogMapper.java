package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.Vlog;

public interface VlogMapper extends MyMapper<Vlog> {
}